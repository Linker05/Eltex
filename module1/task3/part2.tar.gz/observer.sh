#!/bin/bash

WORKDIR="/tmp"
RUNDIR="$WORKDIR/run"

CONFIG="$WORKDIR/observer.conf"
REPORTFILE="$WORKDIR/observer.log"

while read APP; do
    RUNNING=$false
    for PROC in /proc/[0-9]*; do
        FILE=$(cat $PROC/cmdline 2>/dev/null | awk -F '\0' '{print $2}')
        if [[ -z $FILE ]]; then
            continue
        fi
        if [[ $FILE == $APP ]]; then
            RUNNING=$true
            break
        fi
    done
    if [[ ! $RUNNING ]]; then
        nohup "$APP" < /dev/null > /dev/null 2>&1 &
        PID=$!
        printf "$(date +'%d.%m.%Y %T') [$$] $APP перезапущен. PID $PID\n" >> $REPORTFILE
    fi
done < "$CONFIG"
