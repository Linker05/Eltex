#!/bin/bash

NAME="$(basename "$BASH_SOURCE")"

if [[ $NAME == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit
fi

WORKDIR="/tmp"
RUNDIR="$WORKDIR/run"
mkdir -p "$RUNDIR"

REPORTFILE="$WORKDIR/report_$NAME.log"
PIPEFILE="$RUNDIR/cuckoo.pid"

exec 3<>"$PIPEFILE"

printf "$(date +'%d.%m.%Y %T') [$$] Скрипт запущен\n" >> $REPORTFILE

flock 3
echo "$NAME [$$]: how much time do i have?" >&3
flock -u 3
read -u 3 RESULT
sleep $RESULT

printf "$(date +'%d.%m.%Y %T') [$$] Скрипт завершился, работал $RESULT секунд\n" >> $REPORTFILE

