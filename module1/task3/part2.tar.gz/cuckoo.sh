#!/bin/bash

WORKDIR="/tmp"
RUNDIR="$WORKDIR/run"
mkdir -p "$RUNDIR"

NAME="cuckoo"
REPORTFILE="$WORKDIR/$NAME.log"
PIPEFILE="$RUNDIR/cuckoo.pid"

REQ_REGEX="(.*) \[([0-9]+)\]: how much time do i have\?"

mkfifo "$PIPEFILE"
exec 3<>"$PIPEFILE"

trap 'rm -f "$PIPEFILE"; printf "$(date +"%d.%m.%Y %T") Shutdown!\n" >> $REPORTFILE; exit' SIGINT;

printf "$(date +'%d.%m.%Y %T') Startup!\n" >> $REPORTFILE
while $true; do
    read -u 3 MSG
    if [[ $MSG =~ $REQ_REGEX ]]; then
        NAME=${BASH_REMATCH[1]}
        PID=${BASH_REMATCH[2]}
        TIME=$((2 + ($RANDOM % 9)))
	flock 3
        echo $TIME >&3
	flock -u 3
	printf "$(date +'%d.%m.%Y %T') $NAME [$PID] $TIME\n" >> $REPORTFILE
    fi
done

